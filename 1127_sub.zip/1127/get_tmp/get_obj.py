import time
import cv2
from judge import check_temp
from util.drawRoI import drawRoI

import os
def get_temp_idx(path):
    
    idx = 0
    while True:
        if os.path.isfile(path + 'temp_' + str(idx) + '.jpg'):
            idx += 1
        else:
            break
        
    return idx
    
def roi_select(frame):
    img = frame.copy()
    h, w = img.shape[:2]
    r = 20
    
    draw = drawRoI(width = w, height = h , r = r)
    
    cv2.namedWindow("Cut Image", cv2.WINDOW_NORMAL)
    
    cv2.resizeWindow("Cut Image", 640, 480)
    
    draw.call(frame)
    
    while True:
        
        cv2.imshow("Cut Image", draw.show_image())
        key = cv2.waitKey(1)
        
        # Close program with keyboard 'q'
        if key != 255:
            cv2.destroyAllWindows()
            break
        
    
    return draw.get_rectangle()

def check_ROI(tp):
    global judge_space
    path = 'img/'
    file = [ i for i in os.listdir(path) if '.jpg' in i ]
    idx = 0
    
    
    
    
    while True:
        
        frame = cv2.imread(path + file[idx])

        draw = frame.copy()
        #draw = cv2.resize(draw, (1920, 1080), interpolation=cv2.INTER_AREA)
        try:
            draw = cv2.rectangle(draw,(int(judge_space[0]),int(judge_space[1]))
                                          ,(int(judge_space[2]),int(judge_space[3])) , (0, 0, 255), 2)
        except:
            pass
        #draw = cv2.resize(draw, (640, 480), interpolation=cv2.INTER_AREA)
        cv2.namedWindow("reimg", cv2.WINDOW_NORMAL)
    
        cv2.resizeWindow("reimg", 640, 480) 
        cv2.imshow("reimg",draw)
        
        userkeyin = cv2.waitKey(1) & 0xFF
        if userkeyin == ord('1'): # split temp
            judge_space_temp = roi_select(frame.copy())
            if(len(judge_space_temp) == 4):
                judge_space = [int(judge_space_temp[0]) , int(judge_space_temp[1]), int(judge_space_temp[2]), int(judge_space_temp[3])]
                
        if userkeyin == ord('s'): # save temp
            temp_idx = get_temp_idx('temp/')
            if len(judge_space) == 4 :
                cv2.imwrite('temp/temp_'+ str(temp_idx) +'.jpg',frame[judge_space[1]:judge_space[3],judge_space[0]:judge_space[2]])
            judge_space = []
            
        if userkeyin == ord('c'):# check temp now
            check_temp(tp)
            
        if userkeyin == ord('n'):# next image
            idx += 1
            time.sleep(1)
            
        if userkeyin == ord('q'):
            break
        
    cv2.destroyAllWindows()




judge_space = []
tp = 'type' + str(int(input('Key in Type : ')))

check_ROI(tp)

cv2.destroyAllWindows()

    