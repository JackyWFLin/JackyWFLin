import cv2
import os


# In[3]:


def nothing(x):
    pass


# In[4]:


def blur(img,size,times):
    
    for i in range(times):
        img = cv2.blur(img, (size, size))
    #cv2.GaussianBlur(img,(size,size),times)
    return img



scale = 1
img = cv2.imread('roi.jpg')
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

gray_blur = gray
gray_blur = cv2.blur(gray, (7, 7) , 2)
#gray_blur = cv2.equalizeHist(gray_blur)

winName = 'canny tool'
cv2.namedWindow(winName)

cv2.createTrackbar('LowerbH',winName,0,255,nothing)

cv2.createTrackbar('UpperbH',winName,0,255,nothing)

cv2.createTrackbar('binary',winName,0,255,nothing)

cv2.createTrackbar('c1',winName,5,255,nothing)
cv2.createTrackbar('c2',winName,0,255,nothing)

while(1):


    lowerbH=cv2.getTrackbarPos('LowerbH',winName)

    upperbH=cv2.getTrackbarPos('UpperbH',winName)

    binary=cv2.getTrackbarPos('binary',winName)
    
    c1=cv2.getTrackbarPos('c1',winName)
    c1 = c1*2 + 1
    
    c2=cv2.getTrackbarPos('c2',winName)

    ret1, th_binary = cv2.threshold(gray_blur, binary, 255, cv2.THRESH_BINARY)
    #th_binary = cv2.adaptiveThreshold(gray_blur,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C  ,cv2.THRESH_BINARY,c1,c2)

    ret2,th_otsu = cv2.threshold(gray_blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    
    
    cv2.imshow('result3', cv2.resize(th_otsu, (int(gray.shape[1] * scale),int(gray.shape[0] * scale)), interpolation=cv2.INTER_AREA))
    cv2.imshow('otsu',  cv2.resize(gray_blur, (int(gray.shape[1] * scale),int(gray.shape[0] * scale)), interpolation=cv2.INTER_AREA))
    cv2.imshow('binary',  cv2.resize(th_binary, (int(gray.shape[1] * scale),int(gray.shape[0] * scale)), interpolation=cv2.INTER_AREA))

    if cv2.waitKey(1)==ord('q'):

        break


cv2.destroyAllWindows()