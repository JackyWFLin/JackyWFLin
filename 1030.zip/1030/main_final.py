import time
import numpy as np
import os
import cv2
import json

#read config
with open('config/config.json') as f :
    config = json.load(f)
judge_space = config["type1"]["judge_space"]
split_th = np.array(config["type1"]["split_th"])
area_th = config["type1"]["area_th"]

split_h,split_w = split_th.shape 


#read source
img = cv2.imread('source.jpg')
img = img[judge_space[1]:judge_space[3],judge_space[0]:judge_space[2]]
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)



img_h, img_w = gray.shape

judge_img = np.zeros(img.shape[0:2],np.uint8)

step_h = int(img_h/split_h)
step_w = int(img_w/split_w)


gray_blur = gray
gray_blur = cv2.blur(gray, (7, 7) , 2)

cv2.imshow('source' , gray_blur)

#get feature img
for i in range(split_h):
    for j in range(split_w):
        ret1, judge_img[step_h*i:step_h*(i+1),step_w*j:step_w*(j+1)] = cv2.threshold(gray_blur[step_h*i:step_h*(i+1),step_w*j:step_w*(j+1)], split_th[i,j], 255, cv2.THRESH_BINARY)


#filter noise
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
judge_img_morph = cv2.morphologyEx(judge_img, cv2.MORPH_OPEN, kernel, iterations = 2)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
judge_img_morph = cv2.morphologyEx(judge_img_morph, cv2.MORPH_CLOSE, kernel, iterations = 2)


#find object and filter area
obj_pt = []
draw = cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)

_, contours, _ = cv2.findContours(judge_img_morph, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
draw = cv2.drawContours(draw,contours,-1,(0,0,255),2)

for c in contours:
    x,y,w,h = cv2.boundingRect(c)
    area = int(cv2.contourArea(c))
    if (area > area_th * 3) or (area < area_th/2):
        continue;
        
    draw = cv2.putText(draw,str(area),(x,y),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,0),1,cv2.LINE_AA)
    M = cv2.moments(c)
    (cx,cy) = int(M['m10']/M['m00']) , int(M['m01']/M['m00'])
    obj_pt.append([cx,cy])

draw = cv2.putText(draw,"OK Count: " + str(len(obj_pt)),(20,15),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,100,200),1,cv2.LINE_AA)

dist_all = []
for p1 in obj_pt:
    
    dist_temp = []
    for p2 in obj_pt:
        d = int((((p1[0]-p2[0])**2) + ((p1[1]-p2[1])**2))**0.5)
        if d!=0:
            dist_temp.append(d)
    dist_temp.sort()    
    dist_all.extend(dist_temp[0:2])
    
dist_all.sort()   
d_diff = dist_all[-1] - dist_all[0]
draw = cv2.putText(draw,"Dist Diff: " + str(d_diff),(25,35),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,100,200),1,cv2.LINE_AA)                
            


cv2.imshow('result' , judge_img)
cv2.imshow('result2' , draw)
cv2.waitKey(0)
cv2.destroyAllWindows()