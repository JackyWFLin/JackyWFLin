from time import sleep
from picamera import PiCamera
import numpy as np
import cv2

import numpy as np
import os
import cv2
import json
from util.drawRoI import drawRoI


def roi_select(frame):
    img = frame.copy()
    h, w = img.shape[:2]
    
    draw = drawRoI(width = w, height = h)
    
    cv2.namedWindow("Cut Image", cv2.WINDOW_NORMAL)
    
    cv2.resizeWindow("Cut Image", 640, 480)
    
    draw.call(frame)
    
    while True:
        
        cv2.imshow("Cut Image", draw.show_image())
        key = cv2.waitKey(1)
        
        # Close program with keyboard 'q'
        if key == 10:
            cv2.destroyAllWindows()
            break
        
    
    return draw.get_rectangle()


def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)


with open('../config/config.json') as f :
    config = json.load(f)
judge_space = config["judge_space"]

w_scale = 0.3333
h_scale = 0.4444

#w_scale = 1
#h_scale = 1


cap=cv2.VideoCapture(0)

while True:
    try:
        ret, frame = cap.read() # show a frame
    except:
        continue


    cv2.namedWindow("reimg",0)
    draw = frame.copy()
    #draw = cv2.resize(draw, (1920, 1080), interpolation=cv2.INTER_AREA)
    try:
        draw = cv2.rectangle(draw,(int(judge_space[0] * w_scale),int(judge_space[1] * h_scale))
                                          ,(int(judge_space[2] * w_scale),int(judge_space[3] * h_scale)) , (0, 0, 255), 2)
    except:
        draw = frame.copy()
        pass
    draw = cv2.resize(draw, (640, 480), interpolation=cv2.INTER_AREA)
    cv2.imshow("reimg",draw)
    
    userkeyin = cv2.waitKey(1) & 0xFF
    if userkeyin == ord('1'): # Object select
        judge_space_temp = roi_select(frame.copy())
        if(len(judge_space_temp) == 4):
            judge_space = judge_space_temp
            
    if userkeyin == ord('q'):
        break
    
cap.release() 
cv2.destroyAllWindows()





camera = PiCamera()
camera.resolution = (1920, 1080)
image1 = get_image(camera,"test1.jpg")
 
    