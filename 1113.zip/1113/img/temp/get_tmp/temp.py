import cv2
import numpy as np
import json


pt = [548,186]
r = 20

t = cv2.imread('temp.jpg')[ pt[1] - r : pt[1] + r , pt[0] - r : pt[0] + r]
cv2.imwrite('temp_t.jpg',t)

