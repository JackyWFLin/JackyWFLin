from time import sleep
from picamera import PiCamera
import cv2
import json
from util.drawRoI import drawRoI
import RPi.GPIO as GPIO


delay = .01 / 32

def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(12) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

#step_count = [1100,2850,5550]
step_count = [950,1900,2550]

DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)
GPIO.setup(12,GPIO.IN,pull_up_down = GPIO.PUD_UP)

camera = PiCamera()
camera.resolution = (1920, 1080)


init_step(12, STEP, DIR, False)

i_count = 1
for step in step_count:
    move_step(STEP,step, DIR, True)
    image1 = get_image(camera,str(i_count) + ".jpg")
    i_count += 1
    


