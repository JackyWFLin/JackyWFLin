#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2
import numpy as np
import os
import json


# In[ ]:





# In[2]:


def find_obj(img,draw,x,y,h,w):
    w,h = img.shape[::-1]
    t = int(w/4)
    #t = 7
    img[0:t,::] = 0
    img[::,0:t] = 0
    img[h-t::,::] = 0
    img[::,w-t::] = 0
    
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))
    img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel, iterations = 2)
    
    #cv2.imshow('temp', img)
    
    
    _,contours,_ = cv2.findContours(img, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    cnt = sorted(contours, key = lambda x: cv2.contourArea(x), reverse=True)
    
    area = int(cv2.contourArea(cnt[0]))
    
    draw[x:x + h, y:y + w] = cv2.drawContours(draw[x:x + h, y:y + w],[cnt[0]],-1,(0,0,255),0)
    draw = cv2.putText(draw,str(area),(y,x),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,0),1,cv2.LINE_AA)
    
    return draw


# In[ ]:





# In[3]:


with open('config/config.json') as f :
    config = json.load(f)
judge_space = config["judge_space"]


# In[5]:


threshold = 0.85

#image path
path = 'img/'
file = [ i for i in os.listdir(path) if '.jpg' in i ]

#temp path
temp_path = 'img/temp/'
temp_file = [cv2.cvtColor(cv2.imread(temp_path + i),cv2.COLOR_BGR2GRAY) for i in os.listdir(temp_path) if 'temp' in i and '.jpg' in i]
print(len(temp_file))

method = cv2.TM_CCOEFF_NORMED

for f in file:
    print(path + f)
    img_rgb = cv2.imread(path + f)
    img_rgb = img_rgb[judge_space[1]:judge_space[3],judge_space[0]:judge_space[2]]
    draw = img_rgb.copy()
    
    #cv2.imwrite('blur.jpg',cv2.blur(img_rgb, (7, 7) , 2))
    
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    
    
    img_gray = cv2.blur(img_gray, (7, 7) , 2)
    mask = np.zeros(img_rgb.shape[:2], np.uint8)
    
    positions = []
    
    for temp in temp_file:    
        w, h = temp.shape[::-1]    
        match = cv2.matchTemplate(img_gray,temp,method)
        indices = (-match).argpartition(100, axis=None)[:300] # Review the 100 top matches
        unraveled_indices = np.array(np.unravel_index(indices, match.shape)).T
        
        for location in unraveled_indices:
            y, x = location
            confidence = match[y][x]
            if method == cv2.TM_SQDIFF_NORMED or method == cv2.TM_SQDIFF:
                if confidence <= 1-threshold:
                    positions.append(((x, y), confidence, (w, h)))
            else:
                if confidence >= threshold:
                    positions.append(((x, y), confidence, (w, h)))

    obj_pt = []
    #sort all temp result
    positions.sort(key=lambda x: (x[1]), reverse=True)
    for p in positions:
        x,y,h,w, = p[0][1],p[0][0],p[2][1],p[2][0]
        if np.count_nonzero(mask[x:x + h, y:y + w]) == 0:
            if np.std(img_gray[x:x + h ,y:y + w]) > 20:
                obj_pt.append([x,y])
                mask[x : x+h, y : y + w] = 255
                cv2.rectangle(img_rgb, p[0], (y + w, x + h), (0,255,0), 1)
                ret1, binary = cv2.threshold(img_gray[x:x + h ,y:y + w],0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        
                draw = find_obj(binary,draw,x,y,h,w)
                #cv2.imshow('Result', draw)
                #cv2.waitKey(0)
    
    draw = cv2.putText(draw,"OK Count: " + str(len(obj_pt)),(20,15),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,100,200),1,cv2.LINE_AA)
    
    dist_all = []
    for p1 in obj_pt:
        dist_temp = []
        for p2 in obj_pt:
            d = int((((p1[0]-p2[0])**2) + ((p1[1]-p2[1])**2))**0.5)
            if d!=0:
                dist_temp.append(d)
        dist_temp.sort()    
        dist_all.extend(dist_temp[0:2])
        
    dist_all.sort()   
    d_diff = dist_all[-1] - dist_all[0]
    draw = cv2.putText(draw,"Dist Diff: " + str(d_diff),(25,35),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,100,200),1,cv2.LINE_AA)   
    
    
    cv2.imshow('Result', draw)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
        


# In[ ]:




