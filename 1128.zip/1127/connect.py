from time import sleep
import RPi.GPIO as GPIO
import time






DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin
switch_pin = 12


start_pin = 25
reset_pin = 8

#green GND
type_pin1 = 23
type_pin2 = 24

LED_OK_pin = 17

LED_sub_pin1 = 2
LED_sub_pin2 = 3
LED_sub_pin3 = 4

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)

GPIO.setup(LED_OK_pin,GPIO.OUT)
GPIO.setup(LED_sub_pin1,GPIO.OUT)
GPIO.setup(LED_sub_pin2,GPIO.OUT)
GPIO.setup(LED_sub_pin3,GPIO.OUT)

GPIO.setup(switch_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(start_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(reset_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)

GPIO.setup(type_pin1,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(type_pin2,GPIO.IN,pull_up_down = GPIO.PUD_UP)

signal_pin = [5,6,13,19,26]
signal_status = [0,0,0,0,0]



GPIO.setup(signal_pin[0],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[1],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[2],GPIO.OUT)
GPIO.setup(signal_pin[3],GPIO.OUT)
GPIO.setup(signal_pin[4],GPIO.OUT)

tp_dict = {"10":"1","11":"2","01":"3"}


#while (GPIO.input(start_pin)):
#    pass


#print(tp_dict[str(GPIO.input(type_pin1)) + str(GPIO.input(type_pin2))])
a = 1

while True:
    #print(start_pin ,GPIO.input(start_pin))
    #print(reset_pin,GPIO.input(reset_pin))
    
    #print(2 * GPIO.input(type_pin2) + GPIO.input(type_pin1))
    
    #print(GPIO.input(start_pin))
    #print(tp_dict[str(GPIO.input(type_pin1)) + str(GPIO.input(type_pin2))])
    print(GPIO.input(signal_pin[0]))
    time.sleep(0.5)

##LED TEST###
'''
while True:
    print(start_pin ,GPIO.input(start_pin) ,reset_pin,GPIO.input(start_pin))
    
    GPIO.output(LED_OK_pin,True)
    GPIO.output(LED_sub_pin1,False)
    GPIO.output(LED_sub_pin2,False)
    GPIO.output(LED_sub_pin3,False)
    sleep(0.5)
    GPIO.output(LED_OK_pin,False)
    GPIO.output(LED_sub_pin1,True)
    GPIO.output(LED_sub_pin2,True)
    GPIO.output(LED_sub_pin3,True)
    sleep(0.5)
'''

