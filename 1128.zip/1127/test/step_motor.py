from time import sleep
import RPi.GPIO as GPIO

delay = .01 / 32

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(12) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
    

DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)


GPIO.setup(12,GPIO.IN,pull_up_down = GPIO.PUD_UP)
'''
while True:
    print(GPIO.input(12))
    sleep(0.5)
'''
#move_step(STEP,2000, DIR, False)
init_step(12, STEP, DIR, False)