#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2
import numpy as np
import os
import json

path = 'img/'
print(os.listdir(path))