from time import sleep
import cv2
import json
from util.drawRoI import drawRoI
import RPi.GPIO as GPIO

delay = .01 / 32

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(switch_pin) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        

def roi_select(frame):
    img = frame.copy()
    h, w = img.shape[:2]
    
    draw = drawRoI(width = w, height = h)
    
    cv2.namedWindow("Cut Image", cv2.WINDOW_NORMAL)
    
    cv2.resizeWindow("Cut Image", 640, 480)
    
    draw.call(frame)
    
    while True:
        
        cv2.imshow("Cut Image", draw.show_image())
        key = cv2.waitKey(1)
        
        # Close program with keyboard 'q'
        if key != 255:
            cv2.destroyAllWindows()
            break
        
    
    return draw.get_rectangle()

def check_ROI():
    global judge_space
    count = 0;
    
    while True:
        
        ret, frame = cap.read()

        draw = frame.copy()
        #draw = cv2.resize(draw, (1920, 1080), interpolation=cv2.INTER_AREA)
        try:
            draw = cv2.rectangle(draw,(int(judge_space[0] * w_scale),int(judge_space[1] * h_scale))
                                          ,(int(judge_space[2] * w_scale),int(judge_space[3] * h_scale)) , (0, 0, 255), 2)
        except:
            pass
        #draw = cv2.resize(draw, (640, 480), interpolation=cv2.INTER_AREA)
        
        cv2.imshow("reimg",draw)
        
        userkeyin = cv2.waitKey(1) & 0xFF
        if userkeyin == ord('1'): # split select
            judge_space_temp = roi_select(frame.copy())
            if(len(judge_space_temp) == 4):
                judge_space = [int(judge_space_temp[0] / w_scale) , int(judge_space_temp[1] / h_scale), int(judge_space_temp[2] / w_scale), int(judge_space_temp[3] / h_scale)]
        
        if userkeyin == ord('2'): # move motor
            count += 1 
            move_step(STEP,50, DIR, True)
            sleep(0.05)
            
        if userkeyin == ord('3'): # init motor
            count = 0
            init_step(12, STEP, DIR, False)
        
        if userkeyin == ord('p'): # print info
            print("motor step : ",count * 50)
            print("ROI Area : ",judge_space)
            count = 0
            
        
        if userkeyin == ord('m'): # move user keyin
            m = int(input('move step : '))
            move_step(STEP,m, DIR, True)
            
        if userkeyin == ord('q'):
            break
        
    cv2.destroyAllWindows()
    print("step Count" , count * 50)

def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)



judge_space = []

w_scale = 0.3333
h_scale = 0.4444


DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)
GPIO.setup(12,GPIO.IN,pull_up_down = GPIO.PUD_UP)


cap=cv2.VideoCapture(0)
check_ROI()
cap.release() 
cv2.destroyAllWindows()

'''
print("ROI Area : ",judge_space)
json_str = {"judge_space" : judge_space}
with open('config/config.json', 'w') as outfile:
    json.dump(json_str, outfile)
'''

'''
camera = PiCamera()
camera.resolution = (1920, 1080)
image1 = get_image(camera,"source.jpg")
'''
#judge()
    