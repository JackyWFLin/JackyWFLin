import cv2
from time import sleep

# Implement selectROI
class drawRoI:

    def __init__(self, width, height, r):
        self.drawing = False
        self.xmin = 0
        self.ymin = 0
        self.xmax = 0
        self.ymax = 0
        self.rects = []
        self.width = width
        self.height = height
        self.r = r
        
    def draw(self, event, x, y, flags, param):

        if event == cv2.EVENT_LBUTTONDOWN:
            self.clone_image = self.temp_image.copy()
            self.xmin = x
            self.ymin = y
                
        elif event == cv2.EVENT_LBUTTONUP:
            cv2.rectangle(self.clone_image, (self.xmin - self.r, self.ymin - self.r), (x + self.r, y + self.r), (0, 0, 255), 2)
            self.rects = [self.xmin - self.r, self.ymin - self.r, self.xmin + self.r, self.ymin + self.r]
            

                
    def show_image(self):
        return self.clone_image

    def checkEdge(self):
        
        if self.xmax < self.xmin:
            temp = self.xmax
            self.xmax = self.xmin
            self.xmin = temp

        if self.ymax < self.ymin:
            temp = self.ymax
            self.ymax = self.ymin
            self.ymin = temp

        if self.xmin < 0:
            self.xmin = 0
        
        if self.ymin < 0:
            self.ymin = 0

        if self.xmax > self.width:
            self.xmax = self.width - 1
        
        if self.ymax > self.height:
            self.ymax = self.height - 1
        
        

    def get_rectangle(self):
        #if len(self.rects) == 0:
        #    raise ValueError("Need select ROI.")
        return self.rects

    def call(self, frame, win_name="Cut Image"):
        self.original_image = frame
        self.temp_image = frame.copy()
        self.clone_image = self.original_image.copy()
        
        #cv2.namedWindow("Cut Image")
        cv2.setMouseCallback(win_name, self.draw)