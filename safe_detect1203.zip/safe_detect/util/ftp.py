from ftplib import FTP
import cv2
from io import BytesIO

def ftp_remove_dir(ftp,path):
    for (name, properties) in ftp.mlsd(path = path):
        if name in ['.','..']:
            continue
        elif properties['type'] == 'file':
            ftp.delete(f"{path}/{name}")
        elif properties['type'] == 'dir':
            ftp.remove(ftp, f"{path}/{name}")
    ftp.rmd(path)
    
def ftp_create(ip, ac, pw):
    ftp_server = ip
    account = ac
    pw = pw
    ftp = FTP()
    ftp.connect(ftp_server , 21)
    ftp.login(account, pw)
    return ftp

def ftp_create_dir(ftp,fold):
    fold = fold.split('/')
    tmp = ""
    for i in fold:
        if i!='':
            tmp += '/' + i
            try:
                ftp.mkd(tmp)
            except:
                pass

def Upload_Img(ftp, frame, shotTime):
    shotTime = shotTime.strftime("%Y%m%d_%H%M%S")
    try:
        retval, buffer = cv2.imencode('.jpg', frame)
        ioFile = BytesIO(buffer)
        updateFileName = shotTime + ".jpg"
        ftp.storbinary('STOR %s' % updateFileName, ioFile, 4096)
    except:
        print("FTP Connection timed out")