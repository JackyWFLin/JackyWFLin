cd /home/pi/Desktop/safe_detect
python3 GUI.py