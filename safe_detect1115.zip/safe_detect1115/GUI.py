#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tkinter as tk
from tkinter import messagebox

import cv2
import os
import time
import json

from util.drawRoI import drawRoI
from util.ipcamCapture import ipcamCapture


# In[2]:


def roi_select(frame):
    img = frame.copy()
    h, w = img.shape[:2]
    
    draw = drawRoI(width = w, height = h)
    
    cv2.namedWindow("Cut Image", cv2.WINDOW_NORMAL)
    
    cv2.resizeWindow("Cut Image", 640, 480)
    
    draw.call(frame)
    
    while True:
        
        cv2.imshow("Cut Image", draw.show_image())
        key = cv2.waitKey(1)
        
        
        if key == 49 :
            ret, frame = cap.getframe()
            draw.call(frame)
            
        elif key != 255:
            cv2.destroyAllWindows()
            break
    
    return draw.get_rectangle()


# In[3]:


def Add_Obj():
    global obj_info

    obj_no = 1
    if len(obj_info) > 0:
        obj_no = int(obj_info[-1][0].replace('obj_', '')) + 1

    chb_box = []

    if (cb_chb_Value.get()):
        messagebox.showinfo(title='Tips', message='請框選CHB開啟區域')
        ret, frame = cap.getframe()
        chb_box = roi_select(frame.copy())
        cv2.imwrite('config/chb_' + str(obj_no) + '.jpg',
                    frame[chb_box[1]:chb_box[3], chb_box[0]:chb_box[2]])

    messagebox.showinfo(title='Tips', message='請框選物件')
    
    ret, frame = cap.getframe()
    obj_box = roi_select(frame.copy())
    
    ret, frame = cap.getframe()
    cv2.imwrite('config/obj_' + str(obj_no) + '.jpg',
                frame[obj_box[1]:obj_box[3], obj_box[0]:obj_box[2]])

    messagebox.showinfo(title='Tips', message='請框選物件位置')
    ret, frame = cap.getframe()
    area_box = roi_select(frame.copy())

    obj_info.append([
        'obj_' + str(obj_no), obj_box, 'area_' + str(obj_no), area_box,
        'chb_' + str(obj_no), chb_box,
        str(Tb_keep_time.get()),
        str(Tb_Area_th.get()),
        str(Tb_obj_th.get()),
    ])

    obj_list_var.set([i[0] for i in obj_info])
    pass


# In[4]:


def Del_Obj():
    global obj_info
    selected = listbox_obj.curselection()
    if(len(selected) > 0):
        selected = selected[0]
        obj_info.pop(selected)
        obj_list_var.set([i[0] for i in obj_info])


# In[16]:


def Edit_Obj():
    
    
    selected = listbox_obj.curselection()[0]
    obj = obj_info[selected]
    set_value(Tb_keep_time, obj[6])
    set_value(Tb_Area_th, obj[7])
    set_value(Tb_obj_th, obj[8])
    
    
    
    ret, frame = cap.getframe()
    
    #obj
    cv2.rectangle(frame, (obj[1][0],obj[1][1]), (obj[1][2],obj[1][3]), (0, 0, 255), 2)
    
    #obj area
    cv2.rectangle(frame, (obj[3][0],obj[3][1]), (obj[3][2],obj[3][3]), (0, 255, 255), 2)
    
    #chb area
    if len(obj[5]) > 0:
        cb_chb_Value.set(True)
        cv2.rectangle(frame, (obj[5][0],obj[5][1]), (obj[5][2],obj[5][3]), (255, 0, 255), 2)
    else:
        cb_chb_Value.set(False)
        
    cv2.imshow('VIEW', frame)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    


# In[17]:


def set_value(tb,value):
    tb.delete(0,"end")
    tb.insert(0,str(value))


# In[18]:


def file_load():
    global obj_info
    obj_info = []

    config = []
    with open('config/config.json') as f:
        config = json.load(f)
    set_value(Tb_led_ok_pin, config['setting']['LED_OK_pin'])
    set_value(Tb_led_ng_pin, config['setting']['LED_NG_pin'])
    set_value(Tb_beep_pin, config['setting']['beep_pin'])
    set_value(Tb_trigger_pin, config['setting']['trigger_pin'])
    set_value(Tb_trigger_signal, config['setting']['trigger_signal'])

    # obj_info = 'obj_no','pox','area_no','pox','keep_time','area_th','obj_th'
    
    for obj in config['object']:
        if len(obj['chb_pox'].split(','))>1:
            obj_info.append([
                obj['obj_name'], [int(i) for i in obj['obj_pox'].split(',')],
                obj['area_name'], [int(i) for i in obj['area_pox'].split(',')],
                obj['chb_name'], [int(i) for i in obj['chb_pox'].split(',')],
                obj['keep_time'], obj['area_th'], obj['obj_th']
            ])
        else:
            obj_info.append([
                obj['obj_name'], [int(i) for i in obj['obj_pox'].split(',')],
                obj['area_name'], [int(i) for i in obj['area_pox'].split(',')],
                obj['chb_name'], [],
                obj['keep_time'], obj['area_th'], obj['obj_th']
            ])

    set_value(Tb_keep_time, 3)
    set_value(Tb_Area_th, 0.5)
    set_value(Tb_obj_th, 0.7)
    obj_list_var.set([i[0] for i in obj_info])
    tk.messagebox.showinfo('LOAD','Successful !!')


# In[19]:


def file_save():

    json_str = {}
    json_str['setting'] = {
        "LED_OK_pin": str(Tb_led_ok_pin.get()),
        "LED_NG_pin": str(Tb_led_ng_pin.get()),
        "beep_pin": str(Tb_beep_pin.get()),
        "trigger_pin": str(Tb_trigger_pin.get()),
        "trigger_signal": str(Tb_trigger_signal.get())
    }

    idx = 0
    json_str['object'] = []

    for obj in obj_info:
        json_str_temp = {
            'obj_name': obj[0],
            'obj_pox': ",".join([str(o) for o in obj[1]]),
            'area_name': obj[2],
            'area_pox': ",".join([str(o) for o in obj[3]]),
            'chb_name': obj[4],
            'chb_pox': ",".join([str(o) for o in obj[5]]),
            'keep_time': obj[6],
            'area_th': obj[7],
            'obj_th': obj[8]
        }
        json_str['object'].append(json_str_temp)
        idx += 1

    with open('config/config.json', 'w') as outfile:
        json.dump(json_str, outfile)
    tk.messagebox.showinfo('SAVE','Successful !!')


# In[20]:


#Variable Setting
# obj_info = 'obj_no','pox','area_no','pox','keep_time','area_th','obj_th'

if not os.path.exists('config'):
    os.makedirs('config')
cap = ipcamCapture(0)
cap.start()
time.sleep(3)


# In[ ]:





# In[21]:




obj_info = []
win = tk.Tk()
win.title("枕木工安監控")
win.geometry("320x300")

obj_list_var = tk.StringVar()
obj_list_var.set(obj_info)


#icon1 = tk.PhotoImage(file="icon/setting.png")
#icon_start = tk.PhotoImage(file="icon/start.png")

bt_insert = tk.Button(win, text="新增", command=Add_Obj)
bt_delete = tk.Button(win, text="刪除", command=Del_Obj)

bt_save = tk.Button(win, text="匯出", command=file_save)
bt_load = tk.Button(win, text="匯入", command=file_load)

#bt_start = tk.Button(win, text="START",image=icon_start , command=Del_Obj)
#bt_start = tk.Button(win, text="START", command=Del_Obj)


listbox_obj = tk.Listbox(win, listvariable=obj_list_var, height=8)

Tb_led_ok_pin = tk.Entry(win, width=5)
Tb_led_ng_pin = tk.Entry(win, width=5)
Tb_beep_pin = tk.Entry(win, width=5)
Tb_trigger_pin = tk.Entry(win, width=5)
Tb_trigger_signal = tk.Entry(win, width=5)
Tb_keep_time = tk.Entry(win, width=5)
Tb_Area_th = tk.Entry(win, width=5)
Tb_obj_th = tk.Entry(win, width=5)

set_value(Tb_led_ok_pin,26)
set_value(Tb_led_ng_pin,19)
set_value(Tb_beep_pin,13)
set_value(Tb_trigger_pin,17)
set_value(Tb_trigger_signal,1)
set_value(Tb_keep_time,3)
set_value(Tb_Area_th,0.5)
set_value(Tb_obj_th,0.7)



cb_chb_Value = tk.BooleanVar() 
cb_chb = tk.Checkbutton(win, text='CHB Open', var=cb_chb_Value) 




lb_font = ("Times New Roman", 10)





#tk.Label(win,image=icon1).grid(row=0, column=0, padx=5, pady=5, sticky="e")
tk.Label(win, text="Config Setting", font=("Times New Roman", 12)).grid(row=0,column=1,columnspan = 2)
#tk.Label(win,image=icon1).grid(row=0, column=3, padx=5, pady=5)




tk.Label(win, text="LED OK Pin", font=lb_font).grid(row=1,column=0, padx=5, pady=3)
Tb_led_ok_pin.grid(row=1,column=1, padx=5, pady=3)
tk.Label(win, text="LED NG Pin", font=lb_font).grid(row=1,column=2, padx=5, pady=3)
Tb_led_ng_pin.grid(row=1,column=3, padx=5, pady=3)
tk.Label(win, text="Beep Pin", font=lb_font).grid(row=2,column=0, padx=5, pady=3)
Tb_beep_pin.grid(row=2,column=1, padx=5, pady=3)
tk.Label(win, text="Trigger Pin", font=lb_font).grid(row=2,column=2, padx=5, pady=3)
Tb_trigger_pin.grid(row=2,column=3, padx=5, pady=3)
tk.Label(win, text="Trigger signal", font=lb_font).grid(row=3,column=0, padx=5, pady=3)
Tb_trigger_signal.grid(row=3,column=1, padx=5, pady=3)
tk.Label(win, text="Keep Time", font=lb_font).grid(row=3,column=2, padx=5, pady=3)
Tb_keep_time.grid(row=3,column=3, padx=5, pady=3)
tk.Label(win, text="Area Th", font=lb_font).grid(row=4,column=0, padx=5, pady=3)
Tb_Area_th.grid(row=4,column=1, padx=5, pady=3)
tk.Label(win, text="Obj Th", font=lb_font).grid(row=4,column=2, padx=5, pady=3)
Tb_obj_th.grid(row=4,column=3, padx=5, pady=3)

listbox_obj.grid(row=5,column=0, padx=5, pady=5, columnspan = 2, rowspan=5)

cb_chb.grid(row=5,column=2, padx=1)

bt_insert.grid(row=6,column=2, padx=1,sticky="nw")
bt_load.grid(row=6,column=3, padx=1,sticky="nw")

bt_delete.grid(row=7,column=2, padx=1,sticky="nw")
bt_save.grid(row=7,column=3, padx=1,sticky="nw")

#bt_start.grid(row=8,column=2, columnspan = 2, padx=1)

listbox_obj.bind('<Double-Button>', lambda x: Edit_Obj())


win.mainloop()


# In[ ]:





# In[ ]:



