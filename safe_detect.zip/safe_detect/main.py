import RPi.GPIO as GPIO
import time
import numpy as np
import os
import cv2
import json
from util.drawRoI import drawRoI
from util.ipcamCapture import ipcamCapture


def roi_select(frame):
    img = frame.copy()
    h, w = img.shape[:2]
    
    draw = drawRoI(width = w, height = h)
    
    cv2.namedWindow("Cut Image", cv2.WINDOW_NORMAL)
    
    cv2.resizeWindow("Cut Image", 640, 480)
    
    draw.call(frame)
    
    while True:
        
        cv2.imshow("Cut Image", draw.show_image())
        key = cv2.waitKey(1)
        
        # Close program with keyboard 'q'
        if key == 10:
            cv2.destroyAllWindows()
            break
    
    return draw.get_rectangle()


def alarm():
    global beep_count,alarm_type,led_status
    
    
    
    if alarm_type == 0:
        beep_count = 0
        beep.stop()
        GPIO.output(LED_NG_pin,False)
        GPIO.output(LED_OK_pin,led_status)
        led_status = not led_status 
    elif alarm_type == 1:
        beep_count = 0
        beep.stop()
        GPIO.output(LED_OK_pin,True)
        GPIO.output(LED_NG_pin,False)
    else:
        GPIO.output(LED_OK_pin,False)
        GPIO.output(LED_NG_pin,True)
        beep.start(20)
        if beep_count == 0:
            beep_count = 10
    
    '''
    if beep_count > 0:
        beep_count -= 1
        beep.start(20)
    else:
        beep.stop()
    '''
    
    time.sleep(0.3)


# config setting
with open('config/config.json') as f :
    config = json.load(f)
    
LED_OK_pin = int(config["setting"]["LED_OK_pin"])
LED_NG_pin = int(config["setting"]["LED_NG_pin"])
beep_pin = int(config["setting"]["beep_pin"])
trigger_pin = int(config["setting"]["trigger_pin"])
trigger_signal = int(config["setting"]["trigger_signal"])
keep_time = float(config["setting"]["keep_time"])
area_th = float(config["setting"]["area_th"])
obj_th = float(config["setting"]["obj_th"])

tips_text = config["alarm"]["tips_text"]
tips_color = [(int(i.split(',')[0]),int(i.split(',')[1]),int(i.split(',')[2])) for i in config["alarm"]["tips_color"] ]



    




GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(trigger_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(LED_OK_pin,GPIO.OUT)
GPIO.setup(LED_NG_pin,GPIO.OUT)
GPIO.setup(beep_pin,GPIO.OUT)
beep = GPIO.PWM(beep_pin,50)
beep.ChangeFrequency(200)
beep_count = 0




time_Start = time.time()
time_End = time.time()





#cap = cv2.VideoCapture(0)

cap = ipcamCapture(0)
cap.start()
time.sleep(3)
ret, frame = cap.getframe()
# object read
judge_space = []
judge_area_img = np.zeros(frame.shape[0:2],np.uint8)
judge_obj_img = np.zeros(frame.shape[0:2],np.uint8)


obj = []
obj_box = []
obj_check = False
if(os.path.isfile('config/obj.jpg')):
    obj = cv2.imread('config/obj.jpg')
    obj_check = True

if(os.path.isfile('config/judge_space.txt')):
    f = open('config/judge_space.txt','r')
    t = f.read()
    f.close()
    
    judge_space = [int(i) for i in t.split(',')]
    judge_area_img[judge_space[1]:judge_space[3],judge_space[0]:judge_space[2]] = 255
    

#alarm type
trigger = False
alarm_type = 0
led_status = True
tips_img = np.zeros((100,frame.shape[1],3),np.uint8)

area_score = 0
obj_score = 0

while True:
    
    ret, frame = cap.getframe()
    draw = frame.copy()
    
    
    if (GPIO.input(trigger_pin) == trigger_signal):
        if not trigger:
            time_Start = time.time()
            while (GPIO.input(trigger_pin) == trigger_signal):
                time_End = time.time()
                alarm()
                if (time_End - time_Start) > keep_time:
                    trigger = True
                    break
    else:
        trigger = False
        alarm_type = 0
        
        
    if(len(judge_space)!=0):
        cv2.rectangle(draw, (judge_space[0],judge_space[1]), (judge_space[2],judge_space[3]), (0, 255, 255), 2)
    
    
    if obj_check and trigger:
        res = cv2.matchTemplate(frame, obj, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        if (max_val > obj_th):
            cv2.rectangle(draw, (max_loc[0], max_loc[1]), (max_loc[0] + obj.shape[1], max_loc[1] + obj.shape[0]), (0, 0, 255), 2)
            
            obj_score = round(max_val,2)
            #cv2.putText(draw, 'obj_ssim:' + str(round(max_val,2)), (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1, cv2.LINE_AA)
            
            judge_obj_img = np.zeros(frame.shape[0:2],np.uint8)
            judge_obj_img [max_loc[1]:max_loc[1] + obj.shape[0],max_loc[0]:max_loc[0] + obj.shape[1]] = 255
            
            area_score = round(np.count_nonzero(cv2.bitwise_and(judge_area_img,judge_obj_img)) / np.count_nonzero(judge_obj_img),2)
            #cv2.putText(draw, 'area_score:' + str(round(area_score,2)), (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1, cv2.LINE_AA)            
            
            #check obj position
            if(area_score < area_th):
                alarm_type = 3
            else:
                alarm_type = 1
            
        else:
            alarm_type = 2
            pass
    
    
    tips = tips_text[alarm_type]
    tips_img = np.zeros((100,frame.shape[1],3),np.uint8)
    cv2.putText(tips_img, tips, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, tips_color[alarm_type], 2, cv2.LINE_AA)            
    
    cv2.putText(tips_img, '[1] check object image', (450, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,30,30), 1, cv2.LINE_AA)            
    cv2.putText(tips_img, '[2] check area', (450, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,30,30), 1, cv2.LINE_AA)            
    cv2.putText(tips_img, '[enter] confirm', (450, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,30,30), 1, cv2.LINE_AA)            
    if(trigger):
        cv2.putText(tips_img, 'obj score:' + str(obj_score), (520, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1, cv2.LINE_AA)            
        cv2.putText(tips_img, 'area score:' + str(area_score), (510, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1, cv2.LINE_AA)            
    
    
    
    cv2.imshow("image", cv2.vconcat([tips_img,draw]))
    
    # user keyin
    userkeyin = cv2.waitKey(1) & 0xFF
    
    if userkeyin == ord('1'): # Object select
        obj_box_temp = roi_select(frame.copy())
        if(len(obj_box_temp) == 4):
            obj_box = obj_box_temp
            obj = frame[obj_box[1]:obj_box[3],obj_box[0]:obj_box[2]]
            cv2.imwrite('config/obj.jpg',frame[obj_box[1]:obj_box[3],obj_box[0]:obj_box[2]])
            obj_check = True
        
    if userkeyin == ord('2'): # Object select
        judge_space_temp = roi_select(frame.copy())
        if(len(judge_space_temp) == 4):
            judge_space = judge_space_temp
            judge_area_img = np.zeros(frame.shape[0:2],np.uint8)
            judge_area_img[judge_space[1]:judge_space[3],judge_space[0]:judge_space[2]] = 255
            fp = open('config/judge_space.txt','w+')
            fp.write(','.join([str(i) for i in judge_space]))
            fp.close()
        
    
    if userkeyin == ord('q'):
        break
    alarm()
#cap.release()
cap.stop() 
cv2.destroyAllWindows()





