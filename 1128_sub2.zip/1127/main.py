from time import sleep
from picamera import PiCamera
import cv2
import json
import RPi.GPIO as GPIO
import os

from util.judge import judge_obj

delay = .01 / 32

def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(12) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

#step_count = [1100,2850,5550]
step_count = [1250,1700,2550]

DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin
switch_pin = 12

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)
GPIO.setup(switch_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)

camera = PiCamera()
camera.resolution = (1920, 1080)
init_step(switch_pin, STEP, DIR, False)

tp = 'type' + str(int(input('Key in Type : ')))

i_count = 1
img_path = "img/"

with open('config/config.json') as f :
    config = json.load(f)[tp]


temp_path = config['temp_path']
#print(os.listdir(temp_path))
temp_list = [cv2.cvtColor(cv2.imread(temp_path + i),cv2.COLOR_BGR2GRAY) for i in os.listdir(temp_path) if 'temp' in i and '.jpg' in i]

while True:
    try:
        config["obj" + str(i_count)]["area"]
    except:
        break
        
    judge_space = config["obj" + str(i_count)]["area"]
    step_count = int(config["obj" + str(i_count)]["step_count"])
    move_step(STEP,step_count, DIR, True)
    img_rgb = get_image(camera,img_path + 'obj' + str(i_count) + ".jpg")        
    result,judge = judge_obj(img_rgb ,temp_list,config["obj" + str(i_count)])
    print(judge)
    
    i_count += 1
    #except:
    #    break
    
    
