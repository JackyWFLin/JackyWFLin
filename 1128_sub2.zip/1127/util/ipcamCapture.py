import time
import threading
import os
import cv2


class ipcamCapture:
    
    def __init__ (self,URL):
        self.Frame = []
        self.status = False
        self.isstop = False
        self.capture = cv2.VideoCapture(URL)
        
    def start(self):
        print('ipcam started!')
        threading.Thread(target = self.queryframe, daemon = True, args=()).start()
        
    def stop(self):
        self.isstop = True
    
    def getframe(self):
        return self.status,self.Frame.copy()
    
    def queryframe(self):
        while (not self.isstop):
            self.status,self.Frame = self.capture.read()
        