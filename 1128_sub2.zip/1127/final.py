from time import sleep
from picamera import PiCamera
import cv2
import json
import time
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

import os

from util.judge import judge_obj

delay = .01 / 32

def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(12) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

def recive_signal():
    print('wait sub pi signal!')
    global signal_status
    while GPIO.input(signal_pin[2]) == signal_status[2]:
        pass
    time.sleep(0.1)
    signal_status[0] = not signal_status[0]
    GPIO.output(signal_pin[0],signal_status[0])
    signal_status[2] = GPIO.input(signal_pin[2])
    signal_status[3] = GPIO.input(signal_pin[3])
    signal_status[4] = GPIO.input(signal_pin[4])
    print('Done!')
    pass

def send_signal(s1):
    global signal_status
    print('send signal sub pi')
    signal_status[0] = not signal_status[0]
    GPIO.output(signal_pin[0],signal_status[0])
    GPIO.output(signal_pin[1],s1)
    
    while GPIO.input(signal_pin[2]) == signal_status[2]:
        pass
    time.sleep(0.1)
    signal_status[2] = GPIO.input(signal_pin[2])
    signal_status[3] = GPIO.input(signal_pin[3])
    signal_status[4] = GPIO.input(signal_pin[4])
    print('done')

def init_signal():
    print('init signal')
    GPIO.output(signal_pin[0],0)
    GPIO.output(signal_pin[1],0)
    print('wait client init signal!')
    while GPIO.input(signal_pin[2]):
        pass
    print('done')
    
def init_ready_pin():
    for i in range(5):
        for j in LED_sub_pin:            
            GPIO.output(j,1)
        time.sleep(0.3)
        for j in LED_sub_pin:
            GPIO.output(j,0)
        time.sleep(0.3)
        
        


DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin
switch_pin = 12

start_pin = 25
reset_pin = 8

#green GND
type_pin1 = 23
type_pin2 = 24

LED_OK_pin = 17

LED_sub_pin = [2,3,4]


# c,c,s,s,s #client/server
#signal 0/2 syn signal
signal_pin = [5,6,13,19,26]
signal_status = [0,0,0,0,0]
beep_pin = 16


GPIO.setup(signal_pin[0],GPIO.OUT)
GPIO.setup(signal_pin[1],GPIO.OUT)
GPIO.setup(signal_pin[2],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[3],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[4],GPIO.IN,pull_up_down = GPIO.PUD_UP)

GPIO.setup(beep_pin,GPIO.OUT)
GPIO.output(beep_pin,1)

#beep = GPIO.PWM(beep_pin,50)
#beep.ChangeFrequency(600)


GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)

GPIO.setup(LED_OK_pin,GPIO.OUT)
for i in LED_sub_pin:
    GPIO.setup(i,GPIO.OUT)    


GPIO.setup(switch_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(start_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(reset_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)

GPIO.setup(type_pin1,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(type_pin2,GPIO.IN,pull_up_down = GPIO.PUD_UP)

tp_dict = {"10":"type1","11":"type2","01":"type3"}



camera = PiCamera()
camera.resolution = (1920, 1080)


while True:
    signal_status = [0,0,0,0,0]
    init_signal()
    init_ready_pin()
    recive_signal()
    tp = tp_dict[str(signal_status[3]) + str(signal_status[4])]
    print(tp)
    
    
    
    
    #send signal
    
    
    
    i_count = 1
    img_path = "img/"
    
    
    
    with open('config/config.json') as f :
        config = json.load(f)[tp]
    
    
    temp_path = config['temp_path']
    temp_list = [cv2.cvtColor(cv2.imread(temp_path + i),cv2.COLOR_BGR2GRAY) for i in os.listdir(temp_path) if 'temp' in i and '.jpg' in i]
    
    
    
    while True:
        
        try:
            config["obj" + str(i_count)]["area"]
        except:
            break
            
        judge_space = config["obj" + str(i_count)]["area"]
        
        recive_signal()
        img_rgb = get_image(camera,img_path + 'obj' + str(i_count) + ".jpg")
        
        
        result,judge = judge_obj(img_rgb ,temp_list,config["obj" + str(i_count)])
        
        GPIO.output(LED_sub_pin[i_count - 1],judge)
        
        send_signal(judge)
        
        
        i_count += 1
        #except:
        #    break
    
    '''
    signal_status = [0,0,0,0,0]
    init_signal()
    recive_signal()
    if(signal_status[3]):
        for i in range(3):
            GPIO.output(beep_pin,0)
            time.sleep(0.5)
            GPIO.output(beep_pin,1)
            time.sleep(0.5)
    '''
    recive_signal()
