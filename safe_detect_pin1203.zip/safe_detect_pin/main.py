import RPi.GPIO as GPIO
import time
import numpy as np
import cv2
import json
import suds
import os
import ftplib


from skimage.metrics import structural_similarity as ssim
from util.ipcamCapture import ipcamCapture
from util.ftp import *
from datetime import datetime,timedelta


def update_program(sql,value):
    global db_start
    if (time.time() - db_start) > db_delay_time:
        db_start = time.time()
        
        today = datetime.today()
        today_str = datetime.strftime(today,'%Y-%m-%d')
        
        insert_sql = sql
        insert_sql = insert_sql.replace("{ip}",project_id)
        insert_sql = insert_sql.replace("{1}",str(value))
        insert_sql = insert_sql.replace("{2}",today.strftime("%Y-%m-%d %H:%M:%S"))

        try:
            client = suds.client.Client(url, proxy = proxy)
            client.service.exec_mysql_cmd(connstr, insert_sql)
            ftppath = "/IMT/AI_Project/" + project_id + "/" + today_str + "/"
            ftp = ftp_create(ftp_ip, ftp_ac, ftp_pw)
            ftp_create_dir(ftp,ftppath)
            ftp.cwd(ftppath)
            Upload_Img(ftp,img_result,today)
        except:
            pass
        print('update')
        
def blur(img):
    img = cv2.blur(img, (5, 5) , 1)
    return img

def load_img(path):
    img = cv2.imread(path)
    img = blur(img)
    return img

def check_obj(img, obj_img):
    res = cv2.matchTemplate(img, obj_img, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
    
    #cv2.imshow("i1",img)
    #cv2.imshow("i2",obj_img)
    #print('obj ssim:',round(max_val,2))
    #cv2.waitKey(0)
    
    #print(round(max_val,2))
    return round(max_val,2),[max_loc[0], max_loc[1], max_loc[0] + obj_img.shape[1], max_loc[1] + obj_img.shape[0]]

def check_chb(img,obj_img):
    score = ssim(cv2.cvtColor(img,cv2.COLOR_BGR2GRAY) , cv2.cvtColor(obj_img,cv2.COLOR_BGR2GRAY))
    
    #cv2.imshow("i1",img)
    #cv2.imshow("i2",obj_img)
    print('chb ssim:',round(score,2))
    #cv2.waitKey(0)
    
    
    return round(score,2)

def alarm():
    global beep_count,alarm_type,led_status
    
    
    
    if alarm_type == 0:
        beep.stop()
        GPIO.output(LED_NG_pin,False)
        GPIO.output(LED_OK_pin,led_status)
        led_status = not led_status 
    elif alarm_type == 1:
        beep.stop()
        GPIO.output(LED_OK_pin,True)
        GPIO.output(LED_NG_pin,False)
    else:
        GPIO.output(LED_OK_pin,False)
        GPIO.output(LED_NG_pin,True)
        beep.start(20)
    
    
    update_program(insert_sql,alarm_type)
    

    
    time.sleep(0.3)


with open('sql_config/sql_config.json') as f :
    config_data = json.load(f)

connstr = config_data['mysql']['connstr']
insert_sql = config_data['mysql']['insert_sql']
project_id = config_data['mysql']['project_id']
url = config_data['mysql']['url']
proxy = config_data['mysql']['proxy']
db_delay_time = config_data['mysql']['delay_time']

ftp_ip = config_data['ftp']['ip']
ftp_ac = config_data['ftp']['ac']
ftp_pw = config_data['ftp']['pw']
try:
    os.system("sudo ntpdate " + ftp_ip)
except:
    pass

db_start = time.time()
    


# config setting
with open('config/config.json') as f :
    config = json.load(f)
    
LED_OK_pin = int(config["setting"]["LED_OK_pin"])
LED_NG_pin = int(config["setting"]["LED_NG_pin"])
beep_pin = int(config["setting"]["beep_pin"])
trigger_pin = int(config["setting"]["trigger_pin"])
trigger_signal = int(config["setting"]["trigger_signal"])
chb_th = 0.8

with open('util/alarm.json') as f :
    config_alarm = json.load(f)
tips_text = config_alarm["alarm"]["tips_text"]
tips_color = [(int(i.split(',')[0]),int(i.split(',')[1]),int(i.split(',')[2])) for i in config_alarm["alarm"]["tips_color"] ]


obj_info = []
for conf in config["object"]:
    obj_info_temp = []
    obj_info_temp.append(load_img('config/' + conf['obj_name'] + '.jpg'))
    obj_info_temp.append([int(i) for i in conf['area_pox'].split(',')])
    if conf['chb_pox'] != '':
        obj_info_temp.append(load_img('config/' + conf['chb_name'] + '.jpg'))
        obj_info_temp.append([int(i) for i in conf['chb_pox'].split(',')])
    else:
        obj_info_temp.append(None)
        obj_info_temp.append([])
    
    obj_info_temp.append(int(conf['keep_time']))
    obj_info_temp.append(float(conf['obj_th']))
    
    obj_info.append(obj_info_temp)
    




GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(trigger_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
#GPIO.setup(trigger_pin,GPIO.IN)

GPIO.setup(LED_OK_pin,GPIO.OUT)
GPIO.setup(LED_NG_pin,GPIO.OUT)
GPIO.setup(beep_pin,GPIO.OUT)
beep = GPIO.PWM(beep_pin,50)
beep.ChangeFrequency(200)
beep_count = 0




time_Start = time.time()
time_End = time.time()


#cap = cv2.VideoCapture(0)



#obj_status = [[0,0,[],time.time()]] * len(obj_info)
chb_status = [0] * len(obj_info)
obj_status = [0] * len(obj_info)
pt_status = [[]] * len(obj_info)

time_status = [0] * len(obj_info)
obj_time = [time.time()] * len(obj_info)




cap = ipcamCapture(0)
cap.start()
time.sleep(3)
ret, frame = cap.getframe()


#alarm type
trigger = False
alarm_type = 0
led_status = True
tips_img = np.zeros((100,frame.shape[1],3),np.uint8)


while True:
    
    ret, frame = cap.getframe()
    draw = frame.copy()
    #frame = cv2.blur(frame, (5, 5) , 1)
    frame = blur(frame)
    
    if (GPIO.input(trigger_pin) == trigger_signal):
        if not trigger:
            time_Start = time.time()
            while (GPIO.input(trigger_pin) == trigger_signal):
                time_End = time.time()
                alarm()
                if (time_End - time_Start) > 3:
                    chb_status = [0] * len(obj_info)
                    obj_status = [0] * len(obj_info)
                    pt_status = [[]] * len(obj_info)
                    
                    time_status = [0] * len(obj_info)
                    obj_time = [time.time()] * len(obj_info)
                    
                    trigger = True
                    break
    else:
        trigger = False
        alarm_type = 0
        
        
    if trigger:
        alarm_type = 1
        
        for i in range(len(obj_info)):
            #check gatedoor open
            if len(obj_info[i][3]) == 4:
                chb_score = check_chb(frame[obj_info[i][3][1]:obj_info[i][3][3],obj_info[i][3][0]:obj_info[i][3][2]],obj_info[i][2])
                if(chb_score > chb_th):
                    chb_status[i] = 1
                else:
                    chb_status[i] = 0
                
            else:
                chb_status[i] = 1
            
            #check obj
            
            obj_score,obj_pt = check_obj(frame[obj_info[i][1][1]:obj_info[i][1][3],obj_info[i][1][0]:obj_info[i][1][2]],obj_info[i][0])
            if(obj_score > obj_info[i][5]):
                obj_status[i] = 1
                pt_status[i] = obj_pt
            else:
                obj_status[i] = 0
                pt_status[i] = []
                        
        
        for i in range(len(obj_status)):
            #obj in gatedoor
            if obj_status[i]==1 :
                time_status[i] = 0
                cv2.rectangle(draw, (obj_info[i][1][0] , obj_info[i][1][1]), (obj_info[i][1][2], obj_info[i][1][3]), (0, 255, 255), 2)
                cv2.rectangle(draw, (obj_info[i][1][0] + pt_status[i][0], obj_info[i][1][1] + pt_status[i][1]), (obj_info[i][1][0] + pt_status[i][2], obj_info[i][1][1] + pt_status[i][3]), (0, 255, 0), 2)
            else:
            #gatedoor open and obj not in
                if chb_status[i]==1:
                    cv2.rectangle(draw, (obj_info[i][1][0], obj_info[i][1][1]), (obj_info[i][1][2], obj_info[i][1][3]), (0, 0, 255), 2)
                    cv2.putText(draw, 'NG', (obj_info[i][1][0], obj_info[i][1][1]-3), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1, cv2.LINE_AA)
                    if time_status[i] == 0:
                        time_status[i] = 1
                        obj_time[i] = time.time()
                    
                    if (time.time() - obj_time[i]) > obj_info[i][4]:
                        alarm_type = 2
            #gatedoor not open
                else:
                    time_status[i] = 0
                    if len(obj_info[i][3]) != 4:
                        cv2.rectangle(draw, (obj_info[i][1][0], obj_info[i][1][1]), (obj_info[i][1][2], obj_info[i][1][3]), (0, 255, 0), 2)
                    else:
                        cv2.rectangle(draw, (obj_info[i][3][0], obj_info[i][3][1]), (obj_info[i][3][2], obj_info[i][3][3]), (0, 255, 0), 2)
                        cv2.putText(draw, 'Close', (obj_info[i][3][0], obj_info[i][3][1]-3), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0,255,0), 1, cv2.LINE_AA)
                    
                

    
    tips = tips_text[alarm_type]
    tips_img = np.zeros((100,frame.shape[1],3),np.uint8)
    cv2.putText(tips_img, tips, (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, tips_color[alarm_type], 2, cv2.LINE_AA)            
    
    img_result = cv2.vconcat([tips_img,draw])
    cv2.imshow("image", img_result)
    
    # user keyin
    userkeyin = cv2.waitKey(1) & 0xFF
    
    if userkeyin == ord('q'):
        break
    alarm()

cap.stop() 
cv2.destroyAllWindows()





