from time import sleep
from picamera import PiCamera
import cv2
import json
import time
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

import os

from util.judge import judge_obj

delay = .01 / 32

def get_image(camera,img_name):
    sleep(2)
    camera.capture(img_name)
    return cv2.imread(img_name)

def move_step(STEP,step_count,DIR,direct):
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)
        
def init_step(switch_pin ,STEP,DIR,direct):
    
    if(direct):
        GPIO.output(DIR, GPIO.HIGH)
    else:
        GPIO.output(DIR, GPIO.LOW)
    
    while GPIO.input(12) == 1:
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

def send_signal(s1,s2):
    global signal_status
    
    signal_status[2] = not signal_status[2]
    GPIO.output(signal_pin[2],signal_status[2])
    GPIO.output(signal_pin[3],s1)
    GPIO.output(signal_pin[4],s2)
    while GPIO.input(signal_pin[0]) == signal_status[0]:
        pass
    time.sleep(0.1)
    signal_status[0] = GPIO.input(signal_pin[0])
    signal_status[1] = GPIO.input(signal_pin[1])

    pass


DIR = 20       # Direction GPIO Pin
STEP = 21      # Step GPIO Pin
switch_pin = 12

start_pin = 25
reset_pin = 8

#green GND
type_pin1 = 23
type_pin2 = 24

LED_OK_pin = 17

LED_sub_pin1 = 2
LED_sub_pin2 = 3
LED_sub_pin3 = 4

# c,c,s,s,s #client/server
#signal 0/2 syn signal
signal_pin = [5,6,13,19,26]
signal_status = [0,0,0,0,0]



GPIO.setup(signal_pin[0],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[1],GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(signal_pin[2],GPIO.OUT)
GPIO.setup(signal_pin[3],GPIO.OUT)
GPIO.setup(signal_pin[4],GPIO.OUT)

GPIO.output(signal_pin[2],0)
GPIO.output(signal_pin[3],0)
GPIO.output(signal_pin[4],0)


GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.output(DIR, GPIO.HIGH)

GPIO.setup(LED_OK_pin,GPIO.OUT)
GPIO.setup(LED_sub_pin1,GPIO.OUT)
GPIO.setup(LED_sub_pin2,GPIO.OUT)
GPIO.setup(LED_sub_pin3,GPIO.OUT)

GPIO.setup(switch_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(start_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(reset_pin,GPIO.IN,pull_up_down = GPIO.PUD_UP)

GPIO.setup(type_pin1,GPIO.IN,pull_up_down = GPIO.PUD_UP)
GPIO.setup(type_pin2,GPIO.IN,pull_up_down = GPIO.PUD_UP)

tp_dict = {"10":"type1","11":"type2","01":"type3"}



camera = PiCamera()
camera.resolution = (1920, 1080)
init_step(switch_pin, STEP, DIR, False)


# wait start button
while (GPIO.input(start_pin)):
    pass

# get product type
#tp = 'type' + str(int(input('Key in Type : ')))
tp = tp_dict[str(GPIO.input(type_pin1)) + str(GPIO.input(type_pin2))]
send_signal(GPIO.input(type_pin1),GPIO.input(type_pin2))


#send signal


i_count = 1
img_path = "img/"

with open('config/config.json') as f :
    config = json.load(f)[tp]


temp_path = config['temp_path']
temp_list = [cv2.cvtColor(cv2.imread(temp_path + i),cv2.COLOR_BGR2GRAY) for i in os.listdir(temp_path) if 'temp' in i and '.jpg' in i]

while True:
    try:
        config["obj" + str(i_count)]["area"]
    except:
        break
        
    judge_space = config["obj" + str(i_count)]["area"]
    step_count = int(config["obj" + str(i_count)]["step_count"])
    move_step(STEP,step_count, DIR, True)
    
    img_rgb = get_image(camera,img_path + 'obj' + str(i_count) + ".jpg")        
    result,judge = judge_obj(img_rgb ,temp_list,config["obj" + str(i_count)])
    
    send_signal(0,0)
    
    
    print(judge,signal_status[1])
    
    i_count += 1
    #except:
    #    break
    
